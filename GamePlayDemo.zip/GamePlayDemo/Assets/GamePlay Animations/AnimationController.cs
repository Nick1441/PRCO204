﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AnimationController : MonoBehaviour
{
    public Animator alien;
    public Animator playerBook;
    public Animator alienBook;
    public Animator stick;
    public Animator sword;
    public Animator axe;
    
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Animation());
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private IEnumerator Animation()
    {
        alienBook.enabled = false;
        playerBook.enabled = false;
        alien.enabled = false;
        stick.enabled = false;
        axe.enabled = false;
        sword.enabled = false;

        alienBook.gameObject.transform.localScale = new Vector3(0, 0, 0);
        playerBook.gameObject.transform.localScale = new Vector3(0, 0, 0);
        stick.gameObject.transform.localScale = new Vector3(0, 0, 0);
        axe.gameObject.transform.localScale = new Vector3(0, 0, 0);
        sword.gameObject.transform.localScale = new Vector3(0, 0, 0);

        yield return new WaitForSeconds(1);

        alienBook.enabled = true;
        alien.enabled = true;
        alienBook.gameObject.transform.localScale = new Vector3(1.5f, 1.5f, 1.5f);

        yield return new WaitForSeconds(2);

        playerBook.enabled = true;
        playerBook.gameObject.transform.localScale = new Vector3(0.7f, 0.7f, 0.7f);

        stick.enabled = true;
        axe.enabled = true;
        sword.enabled = true;

        yield return new WaitForSeconds(0.99f);
        axe.enabled = false;
        sword.enabled = false;

        yield return new WaitForSeconds(2);
        Destroy(axe.gameObject);
        Destroy(sword.gameObject);
        //playerBook.gameObject.transform.localScale = new Vector3(0, 0, 0);

        yield return new WaitForSeconds(4.5f);
        Destroy(alien.gameObject);
        Destroy(alienBook.gameObject);
        Destroy(stick.gameObject);
        Destroy(playerBook.gameObject);

    }
}
